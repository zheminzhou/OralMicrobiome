import pandas as pd, numpy as np, sys
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.cluster import KMeans
import click
import subprocess

from sklearn.model_selection import GridSearchCV
step = (np.log(1000) - np.log(0.01))/300
linear_param = {'C': np.exp(np.arange(np.log(0.01), np.log(10000)+step, step))}

@click.command()
@click.option('-m', '--method', default='PCA', help='Method to run. Support: PCA, UMAP, Logistic, SVM, LDA, MMDS, NMDS. [Default: UMAP]')
@click.option('-p', '--sparse', required=True, help='output of SPARSE report')
@click.option('-n', '--dim', default=3, help='No. of components')
@click.option('-k', '--kmeans', default=3, help='No. of clusters in Kmeans')
@click.option('-c', '--category', default=None, help='Category of samples. [Default: No category; Required for methods: Logistic, SVM & LDA]')
@click.option('-o', '--outfile', default=None, help='filename for the output. [Default: STDOUT]')
def main(method, sparse, dim, kmeans, category, outfile) :
    mat = pd.read_csv(sparse, sep='\t', dtype=str, header=None).values
    samples = np.vectorize(lambda s:not s.startswith('#'))(mat[0])
    groups = np.vectorize(lambda s:s.startswith('Bacteria') or s.startswith('Vir') or s.startswith('Archaea'))(mat[:, mat[0] == '#Taxon'].ravel())
    sampleNames = mat[0, samples]
    groupNames = mat[groups, 0]
    data = mat[groups][:, samples].astype(float).T
    data = data/np.sum(data, 1).reshape(-1,1)
    
    fout = open(outfile, 'w') if outfile else sys.stdout
    
    if method in ('Logistic', 'SVM', 'LDA') :
        label = pd.read_csv(category, header=None, sep='\t').values
        sampleOrder = {n:i for i, (n, g) in enumerate(label)}
        label = label[np.array([sampleOrder[n] for n in sampleNames])]
        labelNames, labelIds, labelCnts = np.unique(label.T[1], return_inverse=True, return_counts=True)
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = \
            train_test_split(data, labelIds, test_size=.6, random_state=42)
    
        classifiers = dict([
            ['Logistic', GridSearchCV(LogisticRegression(max_iter=3000, solver='lbfgs', multi_class='auto', penalty='l2'), \
                                      linear_param, n_jobs=-1, cv=5, iid=False, return_train_score=True)],
            ['SVM', GridSearchCV(SVC(kernel="linear", probability=True), \
                                 linear_param, n_jobs=-1, cv=5, iid=False, return_train_score=True)],
            ['LDA', LDA(solver='eigen', shrinkage='auto', n_components=min(dim, data.shape[1], labelNames.shape[0]-1))], 
        ])
        
        clf = classifiers[method]
        clf.fit(X_train, y_train)
        subprocess.Popen('''ps -ef|grep semaph|grep python|awk '{print "kill "$2}'|bash''', \
                         stderr=subprocess.PIPE, shell=True).wait()        
        score = clf.score(X_test, y_test)
        fout.write('# {0} - Test score: {1}\n'.format(method, score))
        clf.fit(data, labelIds)
        subprocess.Popen('''ps -ef|grep semaph|grep python|awk '{print "kill "$2}'|bash''', \
                         stderr=subprocess.PIPE, shell=True).wait()
        if method in ('Logistic', 'SVM') :
            clf = clf.best_estimator_
            tr_data = clf.predict_log_proba(data) if method ==' Logistic' else clf.decision_function(data)
        else :
            tr_data = clf.fit_transform(data, labelIds)
        labelling = labelNames[clf.predict(data)]
        w = np.sum(clf.coef_**2, 0)
        w = w/w.max()
        highW = np.argsort(-w)[:100]
        fout.write('#Top 100 most contributed species\n'.format(method, score))
        fout.write('#Group\tWeight\tMeans...\t|\tSTDs...\n'.format(method, score))
        
        for i in highW :
            grp = groupNames[i]
            wi = w[i]
            mean_p, std_p = np.zeros(labelCnts.shape), np.zeros(labelCnts.shape)
            for label in np.arange(labelCnts.size) :
                d = data[labelIds==label, i]
                mean_p[label], std_p[label] = np.mean(d), np.std(d)
            fout.write('{0}\t{1}\t{2}\t|\t{3}\n'.format(grp, wi, '\t'.join(mean_p.astype(str)), '\t'.join(std_p.astype(str))))
        fout.write('\n\n')
        
    else :
        if method == 'UMAP' :
            from umap import UMAP
            model = UMAP(n_components=int(3), n_neighbors=5, random_state=42)
        elif method == 'NMDS' :
            from sklearn.manifold import MDS
            model = MDS(n_components=int(3), metric=False)
        elif method == 'MMDS' :
            from sklearn.manifold import MDS
            model = MDS(n_components=int(3), metric=True)
        else :
            from sklearn.decomposition import PCA
            model = PCA(n_components=int(3))
        tr_data = model.fit_transform( data )
        cls = KMeans(n_clusters=3, n_init=100, max_iter=500)
        cls.fit(tr_data)
        labelling = cls.labels_

    components = ['C_{0}'.format(id) for id in np.arange(dim)] if method != 'PCA' else ['PCA_{0}[{1}]'.format(id, r) for id, r in enumerate(model.explained_variance_ratio_)]
    fout.write('#Sample embedding & clustering\n')
    fout.write('#Samples\tCluster\t{0}\n'.format('\t'.join(components)))
    for n, l, d in zip(sampleNames, labelling, tr_data) :
        fout.write('{0}\t{1}\t{2}\n'.format(n, l, '\t'.join(d.astype(str))))

if __name__ == '__main__' :
    main()