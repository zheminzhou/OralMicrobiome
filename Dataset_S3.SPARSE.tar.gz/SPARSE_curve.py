import pandas as pd, numpy as np, sys
import click

def getCurve(fout, tag, data) :
    fout.write('# {0} - No. samples: {1}\n'.format(tag, data.shape[0] ))
    fout.write('# {0} - No. species: {1}\n'.format(tag, np.sum(np.sum(data > 0, 0) > 0) ))
    fout.write('# {0} - Mean per sample: {1:.1f}\n'.format(tag, np.mean(np.sum(data > 0, 1)) ))
    fout.write('# {0} - Median per sample: {1}\n'.format(tag, np.median(np.sum(data > 0, 1)) ))
    d = np.sum(data > 0, 0)
    d = d[d>0].astype(float)
    d[d >= data.shape[0]] = data.shape[0] - 0.01    
    percentages = np.bincount(((d*10)/data.shape[0]).astype(int), minlength=10)
    for i, p in enumerate(percentages) :
        fout.write('# {0} - {1}-{2}%: {3}\n'.format(tag, i*10, i*10+10, p))
    
    n_ite = 1000
    curves = np.zeros([n_ite, data.shape[0]], dtype=int)
    for ite in np.arange(n_ite) :
        d = np.random.permutation(data)
        curves[ite] = np.sum(np.cumsum(d, 0) > 0, 1)
    fout.write('##Tag\tN_sample\t2.5%\tMedian\t97.5%\n')
    for i, c in enumerate(curves.T) :
        c = np.sort(c)
        fout.write('{0}\t{1}\t{2}\t{3}\t{4}\n'.format(tag, i+1, c[int(n_ite*0.025)], c[int(n_ite*0.5)], c[int(n_ite*0.975)]))
    fout.write('\n')
    
@click.command()
@click.option('-p', '--sparse', required=True, help='output of SPARSE report')
@click.option('-c', '--category', default=None, help='Category of samples. [Default: No category]')
@click.option('-o', '--outfile', default=None, help='filename for the output. [Default: STDOUT]')
def main(sparse, category, outfile) :
    mat = pd.read_csv(sparse, sep='\t', dtype=str, header=None).values
    samples = np.vectorize(lambda s:not s.startswith('#'))(mat[0])
    groups = np.vectorize(lambda s:s.startswith('Bacteria') or s.startswith('Vir') or s.startswith('Archaea'))(mat[:, mat[0] == '#Taxon'].ravel())
    sampleNames = mat[0, samples]
    groupNames = mat[groups, 0]
    data = mat[groups][:, samples].astype(float).T
    #data[data < 0.01] = 0
    
    label = pd.read_csv(category, header=None, sep='\t').values
    sampleOrder = {n:i for i, (n, g) in enumerate(label)}
    label = label[np.array([sampleOrder[n] for n in sampleNames])]
    labelNames, labelIds, labelCnts = np.unique(label.T[1], return_inverse=True, return_counts=True)
    
    fout = open(outfile, 'w') if outfile else sys.stdout
    getCurve(fout, 'all', data)
    for id, n in enumerate(labelNames) :
        d = data[labelIds == id]
        getCurve(fout, n, d)

if __name__ == '__main__' :
    main()
    
    
    