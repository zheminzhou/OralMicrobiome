python SPARSE_ml.py -m SVM -p SPARSE.species.profile -c SPARSE.samples -o SPARSE.species.profile.SVM
python SPARSE_ml.py -m UMAP -p SPARSE.species.profile -c SPARSE.samples -o SPARSE.species.profile.UMAP
python SPARSE_ml.py -m PCA -p SPARSE.species.profile -c SPARSE.samples -o SPARSE.species.profile.PCA
python SPARSE_dist.py -p SPARSE.species.profile
python SPARSE_curve.py -p SPARSE.species.profile -c SPARSE.samples -o SPARSE.species.profile.curves
