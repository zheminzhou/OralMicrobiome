import pandas as pd, numpy as np, sys
import click

def dist(fn, sampleNames, data) :
    distance = np.zeros([data.shape[0], data.shape[0]])
    for i, d in enumerate(data) :
        dist = np.sum((d - data[(i+1):])**2, 1)**0.5
        distance[i, i+1:] = distance[i+1:, i] = dist
    with open(fn, 'w') as fout :
        fout.write('    {0}\n'.format(distance.shape[0]))
        for n, d in zip(sampleNames, distance) :
            fout.write('{0} {1}\n'.format(n, ' '.join(d.astype(str))))
@click.command()
@click.option('-p', '--sparse', required=True, help='output of SPARSE report')
@click.option('-m', '--min', default=0.02, help='Minimum percentage for a group to be clustered')
@click.option('-g', '--group', default=False, is_flag=True, help='Flag to disable merge of groups with the same species name. [Default: False]')
@click.option('-o', '--prefix', default=None, help='filename for the output. [Default: STDOUT]')
def main(sparse, group, min, prefix) :
    prefix = prefix if prefix else sparse
    mat = pd.read_csv(sparse, sep='\t', dtype=str, header=None).values
    samples = np.vectorize(lambda s:not s.startswith('#'))(mat[0])
    groups = np.vectorize(lambda s:s.startswith('Bacteria') or s.startswith('Vir') or s.startswith('Archaea'))(mat[:, mat[0] == '#Taxon'].ravel())
    sampleNames = mat[0, samples]
    groupNames = mat[groups, 0]
    spNames = mat[groups, mat[0] == '#Species']
    
    data = mat[groups][:, samples].astype(float).T
    data = data/np.sum(data, 1).reshape(-1,1)
    dist(prefix+'.sample.dist', sampleNames, data)

    data = data.T
    idx = np.max(data, 1) >= min
    d = data[idx]
    gn = groupNames[idx]

    if not group :
        species = {}
        for grp, sp in zip(groupNames, spNames) :
            species[grp] = sp.split('(')[0].strip().replace('*', '').replace(' ', '_')
        d2 = []
        species_tags = {}
        for t, dd in zip(gn, d) :
            s = species[t]
            if s not in species_tags :
                species_tags[s] = len(d2)
                d2.append(dd)
            else :
                d2[species_tags[s]] += dd
        d = np.array(d2)/np.sum(d2, 1).reshape([-1, 1])
    else :
        d = np.array(d)/np.sum(d, 1).reshape([-1, 1])
    gn = [k for k, v in sorted(species_tags.items(), key=lambda x:x[1])]
    dist(prefix+'.taxon.dist', gn, d)

if __name__ == '__main__' :
    main()